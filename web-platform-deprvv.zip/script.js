console.log('hello!');
let container = document.querySelector('.container');
let sub_container = document.querySelector('.subholder');
class Draggable {
  constructor(container, inner) {
    this.startX = 0;
    this.pressed = false;
    this.x = 0;
    this.container = container;
    this.inner = inner;
  }
  drag() {
    this.container.addEventListener('mousedown', (e) => {
      this.pressed = true;
      e.preventDefault();

      this.startX = e.offsetX - this.inner.offsetLeft;
    });
    window.addEventListener('mousemove', (e) => {
      if (!this.pressed) return;
      e.preventDefault();
      this.x = e.offsetX;
      this.inner.style.left = `${this.x - this.startX}px`;
      this.boundary();
    });
    window.addEventListener('mouseup', (e) => {
      e.preventDefault();
      this.pressed = false;
    });
  }
  boundary() {
    let inner = this.inner.getBoundingClientRect();
    let outer = this.container.getBoundingClientRect();
    if (parseInt(this.inner.style.left) > 0) {
      this.inner.style.left = '0px';
    } else if (inner.right < outer.right) {
      this.inner.style.left = `-${inner.width - outer.width}`;
    }
  }
}
var drag = new Draggable(container, sub_container);
drag.drag();
